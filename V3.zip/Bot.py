from scapy.all import *
import socket
from scapy.layers.inet import UDP
import queue
import threading
import names

# Constants
UDP_PORT = 13117
MAGIC_COOKIE = 0xabcddcba
OFFER_MESSAGE_TYPE = 0x2

def listen_for_udp_offer_scapy():
    tcp_port = [None]  # Use a list to hold the port number due to Python's scoping rules

    def udp_filter(packet):
        if packet.haslayer(UDP) and packet[UDP].dport == UDP_PORT:
            data = packet[UDP].payload.load
            if len(data) >= 7:
                magic_cookie = int.from_bytes(data[:4], 'big')
                message_type = data[4]
                if magic_cookie == MAGIC_COOKIE and message_type == OFFER_MESSAGE_TYPE:
                    tcp_port[0] = int.from_bytes(data[37:39], 'big')  # Adjusted slicing
                    print(f"Offer received on port {tcp_port[0]}")
                    return True  # Indicate that the correct packet was found

    def stop_sniffing(packet):
        return tcp_port[0] is not None  # Stop sniffing if tcp_port is set

    print(f"Listening for offers on UDP port {UDP_PORT}...")
    sniff(filter=f"udp and dst port {UDP_PORT}", prn=udp_filter, stop_filter=stop_sniffing, store=0)
    return tcp_port[0]

def connect_and_play(tcp_port):
    """Connect to the server via TCP, handle trivia questions."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as tcp_socket:
        server_ip = '127.0.0.1'  # Update as necessary
        tcp_socket.connect((server_ip, tcp_port))
        print("Connected to the server.")

        player_name = input_with_timeout_name("your name is: ", 10)
        tcp_socket.sendall(player_name.encode())
        print(player_name.encode().decode())


        while True:
            try:
                # tcp_socket.settimeout(12)  # Set timeout to slightly longer to allow for server processing time.
                message = tcp_socket.recv(1024).decode()
            except socket.timeout:
                print("Connection timed out waiting for a message from the server.")
                continue

            if not message:
                print("Server has closed the connection.")
                break

            if "question:" in message:
                print(message)
                # Use the modified input function with timeout for answering questions
                answer = input_with_timeout("Your answer (Y/N): ")
                tcp_socket.sendall(answer.encode())
            elif "Game over!" in message:
                print(message)
                break
            else:
                print(message)


def input_with_timeout(prompt, timeout=10):
    """Prompt for input with a timeout."""
    print(prompt, end='', flush=True)
    input_queue = queue.Queue()

    def listen_for_input(q):
        try:
            # Simulate user input by randomly choosing between "Y" and "N"
            user_input = random.choice(["Y", "N"])
            q.put(user_input)
            print(user_input)
        except Exception as e:
            print(f"Error receiving input: {e}")

    input_thread = threading.Thread(target=listen_for_input, args=(input_queue,))
    input_thread.daemon = True
    input_thread.start()

    try:
        return input_queue.get(block=True, timeout=timeout)
    except queue.Empty:
        return "E"  # Automatically return "E" after timeout


def input_with_timeout_name(prompt, timeout=10):
    """Prompt for input with a timeout."""
    print(prompt, end='', flush=True)
    input_queue = queue.Queue()

    def listen_for_input(q):
        try:
            user_input = "BOT " + names.get_first_name(gender="female")
            q.put(user_input)
        except Exception as e:
            print(f"Error receiving input: {e}")

    input_thread = threading.Thread(target=listen_for_input, args=(input_queue,))
    input_thread.daemon = True
    input_thread.start()

    try:
        return input_queue.get(block=True, timeout=timeout)
    except queue.Empty:
        return "E"  # Automatically return "E" after timeout





if __name__ == "__main__":
    print("Client started, listening for offer requests with Scapy...")
    tcp_port = listen_for_udp_offer_scapy()
    if tcp_port:
        print(f"Received offer, attempting to connect on port {tcp_port}...")
        connect_and_play(tcp_port)
    else:
        print("No offer received.")