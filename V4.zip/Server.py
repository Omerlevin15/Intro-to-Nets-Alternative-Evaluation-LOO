import socket
from GameStatistics import *
import time
import threading
import copy
import random
import queue
import colorama
colorama.init()


# Initialize global variables
last_player_connection_time = time.time()
connected_players = []
in_game_players = []
broadcasting = True
broadcast_end_event = threading.Event()  # Event to signal the end of broadcasting phase
statistics = GameStatistics()


def create_udp_broadcast_socket():
    """Creates and configures a UDP socket for broadcasting."""
    udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    udp_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    return udp_socket


def send_broadcast_message(udp_socket, server_name, tcp_port, broadcast_ip, udp_port=13117):
    """Sends a broadcast message with a specific packet format."""
    magic_cookie = 0xabcddcba.to_bytes(4, byteorder='big')
    message_type = (0x2).to_bytes(1, byteorder='big')
    server_name_encoded = server_name.encode('utf-8')
    server_name_padded = server_name_encoded.ljust(32, b'\x00')
    server_port_bytes = tcp_port.to_bytes(2, byteorder='big')
    packet = magic_cookie + message_type + server_name_padded + server_port_bytes
    udp_socket.sendto(packet, (broadcast_ip, udp_port))
    print_green(f"Broadcast packet sent to {broadcast_ip}:{udp_port}")


def start_broadcasting(server_name, tcp_port, broadcast_ip="192.168.1.3", udp_port=13117):
    global broadcasting
    udp_socket = create_udp_broadcast_socket()
    try:
        while broadcasting:
            current_time = time.time()
            if current_time - last_player_connection_time > 10:
                print_green("No new players for 10 seconds, stopping broadcasting.")
                broadcasting = False
                broadcast_end_event.set()  # Signal that the broadcasting phase has ended
                broadcast_welcome_message()  # Send the welcome message after the event is set
                break
            send_broadcast_message(udp_socket, server_name, tcp_port, broadcast_ip, udp_port)
            time.sleep(1)
    except KeyboardInterrupt:
        print_green("Broadcasting stopped.")
    finally:
        udp_socket.close()


def broadcast_welcome_message():
    """Sends a welcome message to all connected players."""
    message = "Welcome to the Mystic server, where we are answering trivia questions about Aston Villa FC.\n"
    for i, player in enumerate(connected_players, 1):
        message += f"Player {i}: {player['name']}\n"
    for player in connected_players:
        try:
            player['socket'].sendall(message.encode())
        except Exception as e:
            print_green(f"Error sending welcome message to {player['name']}: {e}")


def handle_client_connection(client_socket):
    global last_player_connection_time, connected_players
    try:
        player_name = client_socket.recv(1024).decode().strip()
        if player_name == "E":
            pass
        elif player_name:
            connected_players.append({'socket': client_socket, 'name': player_name})
            print_green(f"Player {player_name} connected.")
            last_player_connection_time = time.time()  # Update for the last connection
    except Exception as e:
        print_green(f"Error handling connection: {e}")


def accept_tcp_connections(tcp_port):
    global broadcasting
    tcp_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    tcp_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    tcp_socket.bind(('', tcp_port))
    tcp_socket.listen()
    print_green(f"TCP Server listening on port {tcp_port}")

    while not broadcast_end_event.is_set():
        tcp_socket.settimeout(1)  # Set a timeout for the accept call to periodically check the event
        try:
            client_socket, _ = tcp_socket.accept()
        except socket.timeout:
            continue  # Continue checking the event if the accept call times out
        client_thread = threading.Thread(target=handle_client_connection, args=(client_socket,))
        client_thread.start()


def start_trivia_round():
    global connected_players, in_game_players
    trivia_questions = [
        ("True or false: Bees play a crucial role in pollination?", True),
        ("True or false: Dolphins are highly intelligent marine mammals?", True),
        ("True or false: Owls are nocturnal birds of prey?", True),  # Fixed quotation marks here
        ("True or false: Trees absorb carbon dioxide and release oxygen during photosynthesis?", True),
        ("True or false: Penguins are flightless birds that primarily inhabit the Southern Hemisphere?", True),
        ("True or false: Elephants are the largest land animals on Earth?", True),
        ("True or false: Monarch butterflies undergo a long-distance migration each year?", True),
        ("True or false: Honey is produced by bees from nectar collected from flowers?", True),
        ("True or false: Coral reefs are biodiversity hotspots found in tropical marine environments?", True),
        ("True or false: Wolves are social animals that live in packs?", True),
        ("True or false: Sharks are mammals?", False),
        ("True or false: Cacti thrive in moist environments?", False),
        ("True or false: All snakes are venomous?", False),
        ("True or false: Spiders have six legs?", False),
        ("True or false: Bears primarily feed on plants and berries?", False),
        ("True or false: Alligators are native to Europe?", False),
        ("True or false: Venus flytraps capture prey using scent and color?", False),
        ("True or false: Penguins can fly?", False),
        ("True or false: Sunflowers always face east?", False),
        ("True or false: Kangaroos are native to Africa?", False)
        # Add more questions as needed
    ]

    random.shuffle(trivia_questions)
    lock = threading.Lock()
    in_game_players = copy.copy(connected_players)
    counter = 0
    for question, correct_answer in trivia_questions:
        connected_players[:] = [p for p in connected_players if p['socket']]
        if len(connected_players) < 2:
            break

        message = f"following question: {question}\n"
        print_green(message)
        threads = []
        counter += 1
        end_time = time.time() + 10


        for player in connected_players:
            player_thread_instance = threading.Thread(target=player_thread, args=(player, message, correct_answer, end_time, lock))
            threads.append(player_thread_instance)
            player_thread_instance.start()



        for thread in threads:
            thread.join()

        connected_players[:] = [p for p in connected_players if p.get('correct', False)]

        if len(connected_players) <= 1:
            break


    # Game over
    game_over_message = "\nGame over! "
    statistics.print_statistics()
    statistics.write_statistics_to_file()
    if len(connected_players)>1:
        game_over_message += "tie go home"
    elif connected_players:
        game_over_message += f"Congratulations to the winner: {connected_players[0]['name']}"
    else:
        game_over_message += "No winners this round."
    print_green(game_over_message)
    for player in in_game_players:
        try:
            player['socket'].sendall(game_over_message.encode())
        except Exception as e:
            print_green(f"Error sending game over message to {player['name']}: {e}")



def player_thread(player, message, correct_answer, end_time, lock):
    try:
        # Set a timeout based on the end_time for this question.
        player['socket'].sendall(message.encode())
        player['socket'].settimeout(end_time - time.time())
        # Attempt to receive the answer within the timeout period.
        answer = player['socket'].recv(1024).decode().strip().upper()
    except socket.timeout:
        answer = "E"
    except Exception as e:
        print_green(f"Error in player_thread for {player['name']}: {e}")
        return

    with lock:
        if answer == "E":
            # Handle timeout case
            print_green(f"Player {player['name']} timed out.")
            player['answered'] = True
            player['correct'] = False
        elif not answer in ["Y", "T", "1", "N", "F", "0"]:
            # Consider invalid input or no input as incorrect
            print_green(f"Player {player['name']} provided invalid input.")
            player['answered'] = True
            player['correct'] = False
        else:
            correct = (answer in ["Y", "T", "1"] and correct_answer) or (
                        answer in ["N", "F", "0"] and not correct_answer)
            player['answered'] = True
            player['correct'] = correct
            statistics.update_player_performance(player)
            statistics.update_typed_characters(answer)
            response = f"{player['name']} is {'correct' if player['correct'] else 'incorrect'}!\n"
            print_green(response)


def input_with_timeout(prompt, timeout):
    print_green(prompt, end='', flush=True)
    q = queue.Queue()

    def input_thread(q):
        q.put(input())

    it = threading.Thread(target=input_thread, args=(q,))
    it.start()
    it.join(timeout)
    if it.is_alive():
        print_green("\nTime's up! Proceeding with default answer.")
        return "0"  # Default answer when time is up
    else:
        return q.get()


def send_message_to_player(player_socket, message):
    """Send a message to a specific player."""
    try:
        player_socket.sendall(message.encode())
    except Exception as e:
        print_green(f"Error sending message to player: {e}")


def print_green(text):
    print("\033[32m{}\033[0m".format(text))




if __name__ == "__main__":
    server_name = "Mystic"
    tcp_port = 56000
    threading.Thread(target=accept_tcp_connections, args=(tcp_port,)).start()
    start_broadcasting(server_name, tcp_port)
    # Ensure broadcast_welcome_message() is called appropriately
    # Then start the trivia game
    start_trivia_round()
