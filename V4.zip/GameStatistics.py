import json
import collections
from json import JSONDecodeError


class GameStatistics:

    def __init__(self):
        data = self.load_data_from_file()
        self.player_performance = data.get("player_performance", {})
        self.typed_characters = collections.Counter(data.get("typed_characters", {}))

    def load_data_from_file(self):
        try:
            with open('statistics.json', 'r') as file:
                return json.load(file)
        except (FileNotFoundError, JSONDecodeError) as error:
            print(f"Error loading data: {error}")
            return {}

    def update_player_performance(self, player):
        if player["correct"]:
            player_name = player['name']
            if player_name not in self.player_performance:
                self.player_performance[player_name] = 0
            self.player_performance[player_name] += 1
            self.write_statistics_to_file()  # Update JSON file

    def update_typed_characters(self, answer):
        for char in answer:
            self.typed_characters[char] += 1

    def print_statistics(self):
        print("Statistics:")
        # Best Team Ever Played
        if len(self.player_performance) >= 1:
            best_team = max(self.player_performance, key=self.player_performance.get)
            print(f"Best team ever to play on this server: {best_team}")

        # Most Commonly Typed Character
        most_common_character = self.typed_characters.most_common(1)[0][0]
        print(f"Most commonly typed character: {most_common_character}")

    def write_statistics_to_file(self):
        with open('statistics.json', 'w') as file:
            statistics_data = {
                'player_performance': self.player_performance,
                'typed_characters': dict(self.typed_characters)
            }
            json.dump(statistics_data, file)

    def read_statistics_from_file(self):
        with open('statistics.json', 'r') as file:
            statistics_data = json.load(file)
            self.player_performance = statistics_data.get('player_performance', {})
            self.typed_characters = collections.Counter(statistics_data.get('typed_characters', {}))
