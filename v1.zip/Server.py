import socket
import time
import threading

last_player_connection_time = time.time()
connected_players = []
broadcasting = True

def create_udp_broadcast_socket():
    udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    udp_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    return udp_socket

def send_broadcast_message(udp_socket, server_name, tcp_port, broadcast_ip, udp_port=13117):
    magic_cookie = 0xabcddcba.to_bytes(4, byteorder='big')
    message_type = (0x2).to_bytes(1, byteorder='big')
    server_name_encoded = server_name.encode('utf-8')
    server_name_padded = server_name_encoded.ljust(32, b'\x00')
    server_port_bytes = tcp_port.to_bytes(2, byteorder='big')
    packet = magic_cookie + message_type + server_name_padded + server_port_bytes
    udp_socket.sendto(packet, (broadcast_ip, udp_port))
    print(f"Broadcast packet sent to {broadcast_ip}:{udp_port}")

def start_broadcasting(server_name, tcp_port, broadcast_ip="192.168.1.3", udp_port=13117):
    global broadcasting
    udp_socket = create_udp_broadcast_socket()
    try:
        while broadcasting:
            current_time = time.time()
            if current_time - last_player_connection_time > 9999:
                print("No new players for 30 seconds, stopping broadcasting.")
                broadcasting = False
                break
            send_broadcast_message(udp_socket, server_name, tcp_port, broadcast_ip, udp_port)
            time.sleep(1)
    except KeyboardInterrupt:
        print("Broadcasting stopped.")
    finally:
        udp_socket.close()

def broadcast_welcome_message():
    message = "Welcome to the Mystic server, where we are answering trivia questions about Aston Villa FC.\n"
    for i, player in enumerate(connected_players, 1):
        message += f"Player {i}: {player['name']}\n"
    for player in connected_players:
        try:
            player['socket'].sendall(message.encode())
        except Exception as e:
            print(f"Error sending welcome message to {player['name']}: {e}")

def handle_client_connection(client_socket):
    global last_player_connection_time, connected_players
    try:
        player_name = client_socket.recv(1024).decode().strip()
        if player_name:
            connected_players.append({'socket': client_socket, 'name': player_name})
            print(f"Player {player_name} connected.")
            last_player_connection_time = time.time()
    except Exception as e:
        print(f"Error handling connection: {e}")

def accept_tcp_connections(tcp_port):
    global broadcasting
    tcp_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    tcp_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    tcp_socket.bind(('', tcp_port))
    tcp_socket.listen()
    print(f"TCP Server listening on port {tcp_port}")

    while broadcasting:
        try:
            client_socket, _ = tcp_socket.accept()
            client_thread = threading.Thread(target=handle_client_connection, args=(client_socket,))
            client_thread.start()
        except OSError:
            pass
    broadcast_welcome_message()

if __name__ == "__main__":
    server_name = "Mystic"
    tcp_port = 56000  # Adjusted TCP port number
    threading.Thread(target=accept_tcp_connections, args=(tcp_port,)).start()
    start_broadcasting(server_name, tcp_port)
