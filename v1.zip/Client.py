from scapy.all import *
import socket
from scapy.layers.inet import UDP

# Constants
UDP_PORT = 13117
MAGIC_COOKIE = 0xabcddcba
OFFER_MESSAGE_TYPE = 0x2

def listen_for_udp_offer_scapy():
    tcp_port = [None]  # Use a list to hold the port number due to Python's scoping rules

    def udp_filter(packet):
        if packet.haslayer(UDP) and packet[UDP].dport == UDP_PORT:
            data = packet[UDP].payload.load
            if len(data) >= 7:
                magic_cookie = int.from_bytes(data[:4], 'big')
                message_type = data[4]
                if magic_cookie == MAGIC_COOKIE and message_type == OFFER_MESSAGE_TYPE:
                    tcp_port[0] = int.from_bytes(data[37:39], 'big')  # Adjusted slicing
                    print(f"Offer received on port {tcp_port[0]}")
                    return True  # Indicate that the correct packet was found

    def stop_sniffing(packet):
        return tcp_port[0] is not None  # Stop sniffing if tcp_port is set

    print(f"Listening for offers on UDP port {UDP_PORT}...")
    sniff(filter=f"udp and dst port {UDP_PORT}", prn=udp_filter, stop_filter=stop_sniffing, store=0)
    return tcp_port[0]

def connect_and_play(tcp_port):
    """Connect to the server via TCP, send player name, and handle communication."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as tcp_socket:
        # Replace 'server_ip' with the server's IP address
        server_ip = '127.0.0.1'  # Use 'localhost' or '127.0.0.1' for local testing
        # For remote servers, use the appropriate IP address, e.g., server_ip = '192.168.1.5'
        try:
            tcp_socket.connect((server_ip, tcp_port))
            print("Connected to the server.")

            player_name = input("Enter your player name: ") + "\n"
            tcp_socket.sendall(player_name.encode())

            while True:
                message = tcp_socket.recv(1024).decode()
                if not message:
                    print("Server has closed the connection.")
                    break  # Exit if the connection is closed by the server
                print(message)
        except Exception as e:
            print(f"Failed to connect to server: {e}")

if __name__ == "__main__":
    print("Client started, listening for offer requests with Scapy...")
    tcp_port = listen_for_udp_offer_scapy()
    if tcp_port:
        print(f"Received offer, attempting to connect on port {tcp_port}...")
        connect_and_play(tcp_port)
    else:
        print("No offer received.")
